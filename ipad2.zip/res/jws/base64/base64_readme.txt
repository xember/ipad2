Copyright and author of this code: http://www.webtoolkit.info/
Embedded into jWebSocket under the following license: http://www.webtoolkit.info/licence
The source code in base64_obf.js has be shrinked by Jasob Obfuscator
The original source code is provided to you in base64.js